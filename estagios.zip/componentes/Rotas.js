import {createStackNavigator} from '@react-navigation/stack';
import React from 'react';

import Login from './Login';
import Home from './Home';
import Dicas from './Dicas';
import CriarLogin from './CriarLogin';
import Cursos from './Cursos';

const Stack = createStackNavigator();

export default function Rotas(){
    return(
        <Stack.Navigator>
            <Stack.Screen name='Login' component={Login}/>
            <Stack.Screen name='Home' component={Home}/>
            <Stack.Screen name='Dicas' component={Dicas}/>
            <Stack.Screen name='CriarLogin' component={CriarLogin}/>
            <Stack.Screen name='Cursos' component={Cursos}/>
        </Stack.Navigator>
    );
}